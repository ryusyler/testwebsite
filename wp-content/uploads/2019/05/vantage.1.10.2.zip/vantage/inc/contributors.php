<?php
return json_decode( '{
	"b7122312e4008f8f2c76911080bca01a": {
		"name": "Andrew Misplon",
		"email": "b7122312e4008f8f2c76911080bca01a",
		"loc": 1474,
		"score": 78.52581464080393,
		"percent": 54.767299250464276
	},
	"85ce7a450a7ee4895f3bd823505e2e12": {
		"name": "adiraomj",
		"email": "85ce7a450a7ee4895f3bd823505e2e12",
		"loc": 1673,
		"score": 26.48181255409879,
		"percent": 18.469561372641902
	},
	"36639e6e074b731b093bde5a77305179": {
		"name": "Braam Genis",
		"email": "36639e6e074b731b093bde5a77305179",
		"loc": 2184,
		"score": 13.153403556832664,
		"percent": 9.173752504884561
	},
	"5cff8d4385a469d1baab761889ad3161": {
		"name": "Alex S",
		"email": "5cff8d4385a469d1baab761889ad3161",
		"loc": 163,
		"score": 12.844516385622606,
		"percent": 8.958321232790501
	},
	"43c0e7220c23bd6636cf5469be6e9612": {
		"name": "Braam Genis",
		"email": "43c0e7220c23bd6636cf5469be6e9612",
		"loc": 166,
		"score": 8.05592121973424,
		"percent": 5.618547864769192
	},
	"9e7a3b2d24c2b15c53209ba8e7b4e724": {
		"name": "Kevin Batdorf",
		"email": "9e7a3b2d24c2b15c53209ba8e7b4e724",
		"loc": 22,
		"score": 1.8662105989398556,
		"percent": 1.3015759824211723
	},
	"d1bea7e3f82e561c135bf5a3d4f9f896": {
		"name": "SiteOrigin Support",
		"email": "d1bea7e3f82e561c135bf5a3d4f9f896",
		"loc": 13,
		"score": 1.2152238656689478,
		"percent": 0.8475496804692034
	},
	"d203744279876c5eda043108e2611648": {
		"name": "Alex S",
		"email": "d203744279876c5eda043108e2611648",
		"loc": 19,
		"score": 0.7579483014057169,
		"percent": 0.5286259254914877
	},
	"a885c7bd5442dd2acd8c3e42001332c6": {
		"name": "Alex S",
		"email": "a885c7bd5442dd2acd8c3e42001332c6",
		"loc": 22,
		"score": 0.39091665979832696,
		"percent": 0.27264218508396143
	},
	"07294cc1dd7658895e44c559dfffd76f": {
		"name": "gpriday",
		"email": "07294cc1dd7658895e44c559dfffd76f",
		"loc": 21,
		"score": 0.08907391550720362,
		"percent": 0.06212400098373112
	}
}', true );